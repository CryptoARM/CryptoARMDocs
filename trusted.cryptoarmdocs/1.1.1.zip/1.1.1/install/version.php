<?php

$arModuleVersion = array(
    "VERSION" => "1.1.1",
    "VERSION_DATE" => "2018-12-14 10:00:00"
);

