<?php
$updater->CopyFiles("install/js/", "js");

